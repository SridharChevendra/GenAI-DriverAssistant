# import modules

import boto3
import json
import base64
from aws_lambda_powertools import Logger
from aws_lambda_powertools.utilities.typing import LambdaContext

logger = Logger()

# create bedrock object
bedrock = boto3.client(service_name='bedrock-runtime')

# Bedrock model id
bedrock_model_id = 'anthropic.claude-3-sonnet-20240229-v1:0'


# Claude-3 model body
def model_body(input_query):
    body = json.dumps(
        {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 1000,
            "messages": [
                {
                    "role": "user",
                    "content": [
                        # {
                        #     "type": "text"
                        #     },
                        {
                            "type": "text",
                            "text": input_query
                        }
                    ]
                }
            ]
        }
    )
    return body

# Bedrock inference function

def ask_bedrock(bedrock_model_id, model_body):
    try:
        response = bedrock.invoke_model(
            modelId=bedrock_model_id,
            body= model_body
            )
        response_body = json.loads(response['body'].read().decode('utf-8'))
        response_data = response_body['content'][0]['text']
        # print(response_data)
        return response_data
    except:
        return None

def lambda_handler(event, context):
    logger.info({"event": event})

    input_query = event['queryStringParameters']['input_query']
    print(input_query)
    
  
    # build body for bedrock model (Claude -3 model)
    
    body = model_body(input_query)
    print(body)
    
    # bedrock claud3 3 inference
    response = ask_bedrock(bedrock_model_id, body)
    print(response)
    
    return {
        'statusCode': 200,
        # 'body': json.dumps('Hello from Lambda!'),
        'body': json.dumps(response),
        'headers': {
            "content-type":"application/json; charset=utf-8"
                    }
        }
    

